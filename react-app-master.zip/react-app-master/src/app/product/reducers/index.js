import productReducer from "./products";

export default productReducer;