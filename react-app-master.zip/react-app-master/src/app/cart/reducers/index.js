import {combineReducers} from "redux";

import cartReducer from "./cart";

export default cartReducer;
// let rootReducer = combineReducers({
//     items: cartReducer
// })

// export default rootReducer;