//mock for config, injected through webpack externals

export default { 
    apiEndPoint: "example.com",
    authEndPoint: "example.com/oauth/token"
}